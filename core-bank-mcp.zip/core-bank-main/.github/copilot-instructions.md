# CoreBank — GitHub Copilot Instructions

## Project Overview
CoreBank is a personal learning project implementing a **banking microservices system** using Spring Boot.
It consists of 3 independent REST microservices: `accounts`, `cards`, and `loans`.

## Technology Stack
- **Java 17** + **Spring Boot 3.4.5**
- **Spring Data JPA** with **H2 in-memory database** (per service)
- **Jakarta Bean Validation** for input validation
- **Lombok** for boilerplate reduction (`@Data`, `@AllArgsConstructor`, etc.)
- **SpringDoc OpenAPI** (accounts) / **swagger-annotations-jakarta** (cards, loans) for API docs
- **Spring JPA Auditing** via `AuditAwareImpl` for `createdAt/By`, `updatedAt/By` fields
- **Maven** build tool
- Manual mapper classes (no MapStruct) in the `mapper/` package

## Microservice Details

| Service  | Port | Package Base                    |
|----------|------|---------------------------------|
| accounts | 8080 | `com.corebank.accounts`         |
| cards    | 9001 | `com.corebank.cards`            |
| loans    | 8090 | `com.corebank.loans`            |

## Standard Project Structure (same for all 3 services)
```
src/main/java/com/corebank/{service}/
  ├── {Service}Application.java       # Main class with @OpenAPIDefinition
  ├── audit/AuditAwareImpl.java       # Returns "{SERVICE}_MS" as auditor
  ├── constants/{Service}Constants.java
  ├── controller/{Service}Controller.java
  ├── dto/                            # DTOs with validation annotations + Swagger @Schema
  ├── entity/                         # JPA entities extending BaseEntity
  ├── exception/
  │   ├── GlobalExceptionHandler.java # @ControllerAdvice
  │   ├── ResourceNotFoundException.java
  │   └── {Resource}AlreadyExistsException.java
  ├── mapper/{Service}Mapper.java     # Static mapping methods
  ├── repository/{Service}Repository.java
  └── service/
      ├── I{Service}Service.java      # Interface
      └── impl/{Service}ServiceImpl.java
```

## REST API Pattern (uniform across all services)
All services expose 4 endpoints under `/api`:
```
POST   /api/create   → create a new resource (mobileNumber as @RequestParam or in body)
GET    /api/fetch    → fetch by ?mobileNumber
PUT    /api/update   → full update via @RequestBody
DELETE /api/delete   → delete by ?mobileNumber
```
- All controllers are annotated with `@RestController`, `@RequestMapping(path="/api")`, `@Validated`, `@AllArgsConstructor`
- Return types: `ResponseEntity<ResponseDto>` for mutations, `ResponseEntity<{Resource}Dto>` for fetch
- Mobile number validation pattern: `(^$|[0-9]{10})`

## Domain Models

### accounts service
- `Customer`: customerId (PK), name, email, mobileNumber
- `Accounts`: accountNumber (PK, random 10-digit), customerId (FK), accountType, branchAddress
- Default: type=`Savings`, address=`"123 Main Street, New York"`

### cards service
- `Cards`: cardId (PK), mobileNumber, cardNumber (random 12-digit), cardType, totalLimit, amountUsed, availableAmount
- Default: type=`Credit Card`, limit=`100_000`

### loans service
- `Loans`: loanId (PK), mobileNumber, loanNumber (random 12-digit), loanType, totalLoan, amountPaid, outstandingAmount
- Default: type=`Home Loan`, limit=`100_000`

## Coding Conventions
- Always extend `BaseEntity` for audit fields (`createdAt`, `createdBy`, `updatedAt`, `updatedBy`)
- Always annotate DTOs with `@Schema` (description + example) for OpenAPI docs
- Always annotate controller methods with `@Operation`, `@ApiResponses`
- Use `@Tag` on controller class for Swagger grouping
- Throw `ResourceNotFoundException("EntityName", "fieldName", fieldValue)` when entity not found
- Throw `{Resource}AlreadyExistsException` on duplicate creation
- Use static mapper methods: `Mapper.mapToDto(entity, new Dto())` and `Mapper.mapToEntity(dto, entity)`
- Constants class must be `final` with a `private` constructor

## What Is NOT In This Project Yet (planned enhancements)
- No API Gateway (Spring Cloud Gateway planned)
- No Service Discovery (Eureka/Consul planned)
- No Spring Cloud Config Server
- No inter-service communication (OpenFeign planned)
- No Spring Security / JWT / OAuth2
- No Docker / docker-compose
- No Kubernetes manifests
- No distributed tracing (Micrometer + Zipkin/Jaeger)
- No event-driven messaging (Kafka/RabbitMQ)
- No MCP server integration yet (planned)

## MCP (Model Context Protocol) Integration Plans
The project plans to add an MCP server that exposes CoreBank operations as AI tools:
- `create_account(name, email, mobileNumber)` → calls accounts service
- `fetch_customer_360(mobileNumber)` → aggregates accounts + cards + loans
- `create_card(mobileNumber)` → calls cards service
- `create_loan(mobileNumber)` → calls loans service
- `get_all_service_health()` → checks actuator health for all 3 services
When implementing MCP tools, use `@Tool` annotation pattern (Spring AI MCP) or raw MCP SDK.

## Code Generation Rules for Copilot
When generating new code for this project:
1. Follow the existing 3-layer pattern: Controller → Service Interface → ServiceImpl → Repository
2. Always add Swagger annotations (`@Operation`, `@ApiResponse`, `@Schema`)
3. Use Lombok — never write explicit getters/setters
4. Add validation annotations on all DTO fields
5. Copy the `GlobalExceptionHandler` pattern for any new service
6. New entities must extend `BaseEntity`
7. New constants go in the `constants/` package as a `final` class
8. Use constructor injection via `@AllArgsConstructor` — never `@Autowired` on fields
9. H2 schema goes in `src/main/resources/schema.sql`
10. Keep `application.yml` consistent with existing services (H2 config, show-sql: true)

## Common Commands
```bash
# Run individual services
cd accounts && ./mvnw spring-boot:run
cd cards    && ./mvnw spring-boot:run
cd loans    && ./mvnw spring-boot:run

# Build
cd accounts && ./mvnw clean package

# Access Swagger UI (accounts only currently)
http://localhost:8080/swagger-ui.html

# H2 Console (all services)
http://localhost:8080/h2-console   # accounts
http://localhost:9001/h2-console   # cards
http://localhost:8090/h2-console   # loans
```
